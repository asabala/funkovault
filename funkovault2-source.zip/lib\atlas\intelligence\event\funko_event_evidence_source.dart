enum FunkoEventEvidenceSource { token, phrase }
