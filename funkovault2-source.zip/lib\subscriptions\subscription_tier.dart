enum SubscriptionTier { basic, premium }
